CAREER PLANNER UI UPGRADE

Files:
- templates/onboarding/profile.html
- static/css/onboarding.css
- templates/onboarding/schedule.html
- static/css/schedule.css
- static/css/style.css
- BACKEND_PATCH.txt

What changed:
1. Profile onboarding now uses the same premium visual language as Skills.
2. Added Step 5: Schedule / Availability.
3. Schedule collects college hours, preferred study window, daily study capacity,
   available days and session style.
4. Home page CSS is redesigned without changing the user's existing home.html,
   so existing button edits are preserved.
5. Backend patch adds StudentAvailability and the /onboarding/schedule route.

IMPORTANT:
- Apply BACKEND_PATCH.txt manually to models.py/app.py.
- Keep your existing skills implementation.
- After successful skills submission, redirect to onboarding_schedule.
- Run: python -m py_compile models.py app.py
- Then run: python app.py

Do not delete the existing SQLite database just for this UI change.
